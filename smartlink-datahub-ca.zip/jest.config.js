module.exports = {
  testEnvironment: 'node',
  transform: {
    '^.+.tsx?$': ['ts-jest', {}],
  },
  reporters: [
    'default',
    [
      'jest-junit',
      {
        outputDirectory: './test-results',
        outputName: 'result.xml',
      },
    ],
  ],
  collectCoverageFrom: ['src/services/EventService.ts'],
  coverageReporters: ['lcov', 'cobertura', 'html'], // Include 'cobertura' if needed
  coverageDirectory: 'coverage',
};
