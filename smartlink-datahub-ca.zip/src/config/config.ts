import * as dotenv from 'dotenv';
import {z, ZodIssue} from 'zod';

dotenv.config({path: '.env'});

const configSchema = z.object({
  MSSQL_HOST: z.string().min(1),
  MSSQL_USERNAME: z.string().min(1),
  MSSQL_PASSWORD: z.string().min(1),
});

export type Config = z.infer<typeof configSchema>;

let config: Config | undefined = undefined;

export function getConfig(): Config {
  if (!config) {
    config = initializeConfig();
  }

  return config;
}

export function initializeConfig(): Config {
  const parsed = configSchema.safeParse(process.env);
  if (!parsed.success) {
    const formatted_errors: string[] = parsed.error.errors.map((err: ZodIssue) => {
      return JSON.stringify(err);
    });
    throw new TypeError(formatted_errors.toString());
  }
  return parsed.data;
}
