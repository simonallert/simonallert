import {DataSource} from 'typeorm';
import {getConfig} from './config';

export const mssql_datasource = new DataSource({
  type: 'mssql',
  host: getConfig().MSSQL_HOST,
  port: 1433,
  username: getConfig().MSSQL_USERNAME,
  password: getConfig().MSSQL_PASSWORD,
  entities: ['./build/db/entities/*.js', './build/db/datahub/*.js'],
  migrationsRun: true,
  migrations: ['./build/db/migrations/*.js'],
  logging: true,
  extra: {
    ssl: true,
  },
  synchronize: false, //! NEVER SET THIS TO TRUE
  options: {
    trustServerCertificate: true,
    encrypt: true,
  },
});

export async function close_db_connection(): Promise<void> {
  try {
    await mssql_datasource.destroy();
    console.log('Database connection closed.');
  } catch (error) {
    console.error('Error closing database connection:', error);
  }
}
