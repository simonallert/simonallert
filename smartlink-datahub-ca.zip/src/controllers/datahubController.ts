// import EntityService from "../services/entityService";

// interface IJobController {
//   processMessage(data: string): Promise<boolean>;
//   blobZip(identifier: string, job_run: JobRun, files: {sourcePath: string; zipPath: string}[], zippath: string): Promise<void>;
//   add_file_to_zip(archive: archiver.Archiver, containerClient: ContainerClient, file: {sourcePath: string; zipPath: string}, job_run: JobRun, identifier: string): Promise<void>;
//   calculate_generation_time(containerClient: ContainerClient, files: {sourcePath: string; zipPath: string}[], uploadSpeedMBps: number): Promise<{total_size: number; estimated_time: number}>;
// }

// export class JobController implements IJobController {
//   private entityService: EntityService;
//   private esfc_azureBlobStorageService: AzureBlobStorageService;
//   private orchestrator_azureBlobStorageService: AzureBlobStorageService;

//   constructor(
//     entityService: EntityService,
//     esfc_azureBlobStorageService: AzureBlobStorageService,
//     orchestrator_azureBlobStorageService: AzureBlobStorageService,
//   ) {
//     this.entityService = entityService;
//     this.esfc_azureBlobStorageService = esfc_azureBlobStorageService;
//     this.orchestrator_azureBlobStorageService = orchestrator_azureBlobStorageService;
//   }

//   async test(){
//     this.eventService.createnetity();
//   }
// }
