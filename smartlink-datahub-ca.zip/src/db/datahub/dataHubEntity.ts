import {Column, PrimaryColumn, VersionColumn} from 'typeorm';

export abstract class DataHubEntity {
  @PrimaryColumn({type: 'varchar'})
  generatedDdhKey: string;

  @Column({type: 'bit', default: 0})
  deletionFlag: boolean;

  @VersionColumn()
  version: number;
}
