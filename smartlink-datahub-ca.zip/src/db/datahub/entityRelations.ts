import {BaseEntity, Column, CreateDateColumn, Entity, PrimaryColumn, UpdateDateColumn} from 'typeorm';

@Entity('entityRelations')
export class EntityRelations extends BaseEntity {
  @PrimaryColumn({type: 'varchar'})
  leftSourceSystemId: string;

  @PrimaryColumn({type: 'varchar'})
  leftEntity: string;

  @PrimaryColumn({type: 'varchar'})
  leftGeneratedKey: string;

  @PrimaryColumn({type: 'varchar'})
  rightSourceSystemId: string;

  @PrimaryColumn({type: 'varchar'})
  rightEntity: string;

  @PrimaryColumn({type: 'varchar'})
  rightGeneratedKey: string;

  @PrimaryColumn({type: 'varchar'})
  relationType: string;

  @Column({type: 'varchar', nullable: true})
  expandTypeName: string;

  @Column({type: 'datetime', nullable: true})
  sourceRecordExistenceDateTime: Date;

  @CreateDateColumn()
  relationInitialPersistenceDateTime: Date;

  @UpdateDateColumn()
  relationUpdatePersistenceDateTime: Date;

  @Column({type: 'bit', default: 0})
  relationDeleted: boolean;

  @Column({type: 'datetime', nullable: true})
  relationDeletionDateTime: Date;
}
