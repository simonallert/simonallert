import {BaseEntity, Column, Entity, PrimaryColumn} from 'typeorm';

export enum PropagateDelete {
  LEFT_TO_RIGHT = 'LeftToRight',
  RIGHT_TO_LEFT = 'RightToLeft',
}

export enum RelationType {
  PARENT_CHILD = 'ParentChild',
  EXPAND = 'Expand',
}

@Entity('leftRightEntityRelations')
export class LeftRightEntityRelations extends BaseEntity {
  @PrimaryColumn({type: 'varchar'})
  leftSourceSystemId: string;

  @PrimaryColumn({type: 'varchar'})
  leftEntity: string;

  @PrimaryColumn({type: 'varchar'})
  rightSourceSystemId: string;

  @PrimaryColumn({type: 'varchar'})
  rightEntity: string;

  @Column({type: 'varchar', enum: PropagateDelete, nullable: true})
  propagateDelete: PropagateDelete;

  @PrimaryColumn({type: 'varchar', enum: RelationType})
  relationType: RelationType;

  @Column({type: 'varchar', nullable: true})
  expandTypeName: string;
}
