import {BaseEntity, Column, Entity, PrimaryColumn} from 'typeorm';

@Entity('leftRightEntityRelationsMapping')
export class LeftRightEntityRelationsMapping extends BaseEntity {
  @PrimaryColumn({type: 'varchar'})
  leftSourceSystemId: string;

  @PrimaryColumn({type: 'varchar'})
  leftEntity: string;

  @PrimaryColumn({type: 'varchar'})
  rightSourceSystemId: string;

  @PrimaryColumn({type: 'varchar'})
  rightEntity: string;

  @PrimaryColumn({type: 'varchar'})
  leftAttribute: string;

  @Column({type: 'varchar', nullable: true})
  rightAttribute: string;
}
