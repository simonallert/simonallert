import {Column, CreateDateColumn, Entity, PrimaryColumn, UpdateDateColumn} from 'typeorm';
import {DataHubEntity} from './dataHubEntity';
//check to hash without implementation of random package.
import {Md5} from 'ts-md5';
import {SourceSystemEntity} from './sourceSystemEntity';

@Entity('registeredSourceSystemEntityDataKey')
export class RegisteredSourceSystemEntityDataKey {
  @PrimaryColumn({type: 'varchar'})
  sourceSystemId: string;

  @PrimaryColumn({type: 'varchar'})
  entity: string;

  @PrimaryColumn({type: 'varchar'})
  generatedDdhKey: string;

  @Column({type: 'datetime', nullable: true})
  sourceRecordChangeDateTime: Date;

  @Column({type: 'datetime', nullable: true})
  sourceRecordExistanceDateTime: Date;

  @CreateDateColumn()
  ddhKeyCreationDateTime: Date;

  @UpdateDateColumn()
  ddhKeyUpdateDateTime: Date;

  @Column({type: 'varchar', nullable: true})
  integrationId: string;

  @Column({type: 'int', nullable: true})
  entityVersion: number;

  @Column({type: 'varchar', nullable: true})
  valueHash: string;

  @Column({type: 'bit', default: 0})
  deletedInSource: boolean;

  @Column({type: 'datetime', nullable: true})
  deletedInSourceDateTime: Date;

  @Column({type: 'datetime', nullable: true})
  ddhInitialPersistenceDateTime: Date;

  @Column({type: 'datetime', nullable: true})
  ddhUpdatePersistenceDateTime: Date;

  @Column({type: 'datetime', nullable: true})
  hashInitialDateTime: Date;

  @Column({type: 'datetime', nullable: true})
  hashCheckedDateTime: Date;

  static readonly keyLayoutTemplateDefaultPart = 'SourceSystemId|#|Entity|#|';

  constructor(entityConfig: SourceSystemEntity, entity: DataHubEntity) {
    this.sourceSystemId = entityConfig?.sourceSystemId;
    this.entity = entityConfig?.entity;
    this.generatedDdhKey = RegisteredSourceSystemEntityDataKey.generateDdhKeyForEntity(entityConfig, entity);
    if (entityConfig?.dataValueHashing) {
      this.hash(entity);
    }
  }

  static generateDdhKeyForEntity(entityConfig: SourceSystemEntity, entity: any): string {
    const idString = entityConfig?.keyLayoutTemplate.replace(RegisteredSourceSystemEntityDataKey.keyLayoutTemplateDefaultPart, '');
    const id = entity?.[idString];
    return RegisteredSourceSystemEntityDataKey.generateDdhKey(entityConfig?.sourceSystemId, entityConfig?.entity, id);
  }

  static generateDdhKeyWithId(entityConfig: SourceSystemEntity, id: any): string {
    return RegisteredSourceSystemEntityDataKey.generateDdhKey(entityConfig?.sourceSystemId, entityConfig?.entity, id);
  }

  private static generateDdhKey(sourceSystem: string, entityType: string, id: any): string {
    return sourceSystem + '|#|' + entityType + '|#|' + id;
  }

  private hash(entity: any): void {
    if (entity) {
      this.valueHash = Md5.hashStr(JSON.stringify(entity));
      this.hashInitialDateTime = new Date();
    }
  }
}
