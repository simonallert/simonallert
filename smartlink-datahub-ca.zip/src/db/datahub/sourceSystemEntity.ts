import {Column, Entity, PrimaryColumn} from 'typeorm';

@Entity('sourceSystemEntity')
export class SourceSystemEntity {
  @PrimaryColumn({type: 'varchar'})
  sourceSystemId: string;

  @PrimaryColumn({type: 'varchar'})
  entity: string;

  @Column({type: 'varchar'})
  keyLayoutTemplate: string;

  @Column({type: 'bit'})
  dataValueHashing: boolean;

  @Column({type: 'bit'})
  updateSourceTableContentOnEqualHash: boolean;

  @Column({type: 'bit'})
  deletionDetectionActive: boolean;

  @Column({type: 'datetime', nullable: true})
  cutOffDateTimeAttribute: Date;
}
