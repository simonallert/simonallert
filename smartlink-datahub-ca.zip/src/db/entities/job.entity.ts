import {Column, Entity} from 'typeorm';
import {DataHubEntity} from '../datahub/dataHubEntity';

@Entity('job')
export class Job extends DataHubEntity {
  @Column({type: 'int'})
  id: number;

  @Column({type: 'varchar', nullable: true})
  description: string;
}
