import {Column, Entity} from 'typeorm';
import {DataHubEntity} from '../datahub/dataHubEntity';

@Entity('skill')
export class Skill extends DataHubEntity {
  @Column({type: 'int'})
  id: number;

  @Column({type: 'varchar', nullable: true})
  defaultName: string;

  @Column({type: 'int', nullable: true})
  sequence: number;

  @Column({type: 'bit', nullable: true})
  active: boolean;

  @Column({type: 'datetime', nullable: true})
  creationDate: Date;

  @Column({type: 'int', nullable: true})
  creatorId: number;

  @Column({type: 'int', nullable: true})
  parentId: number;

  @Column({type: 'bit', nullable: true})
  isDeleted: boolean;

  @Column({type: 'datetime', nullable: true})
  useEndDate: Date;

  @Column({type: 'varchar', nullable: true})
  externalCode: string;

  @Column({type: 'bit', nullable: true})
  isFunction: boolean;
}
