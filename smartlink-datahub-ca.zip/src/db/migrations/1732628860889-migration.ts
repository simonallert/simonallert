import {MigrationInterface, QueryRunner} from 'typeorm';

export class Migration1732628860889 implements MigrationInterface {
  name = 'Migration1732628860889';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "skill" ("generatedDdhKey" varchar(255) NOT NULL, "deletionFlag" bit NOT NULL CONSTRAINT "DF_f01a7cc3ac207ecb13779efa447" DEFAULT 0, "version" int NOT NULL, "id" int NOT NULL, "defaultName" varchar(255), "sequence" int, "active" bit, "creationDate" datetime, "creatorId" int, "parentId" int, "isDeleted" bit, "useEndDate" datetime, "externalCode" varchar(255), "isFunction" bit, CONSTRAINT "PK_08b3da3ccd58d30cbaf8a071de8" PRIMARY KEY ("generatedDdhKey"))`,
    );
    await queryRunner.query(
      `CREATE TABLE "sourceSystemEntity" ("sourceSystemId" varchar(255) NOT NULL, "entity" varchar(255) NOT NULL, "keyLayoutTemplate" varchar(255) NOT NULL, "dataValueHashing" bit NOT NULL, "updateSourceTableContentOnEqualHash" bit NOT NULL, "deletionDetectionActive" bit NOT NULL, "cutOffDateTimeAttribute" datetime, CONSTRAINT "PK_077d2811f1ed76cf00a1debaabb" PRIMARY KEY ("sourceSystemId", "entity"))`,
    );
    await queryRunner.query(
      `CREATE TABLE "job" ("generatedDdhKey" varchar(255) NOT NULL, "deletionFlag" bit NOT NULL CONSTRAINT "DF_0f08a872c5134838ffb4e04d485" DEFAULT 0, "version" int NOT NULL, "id" int NOT NULL, "description" varchar(255), CONSTRAINT "PK_7f701678b194f386c9bcb8fbf5d" PRIMARY KEY ("generatedDdhKey"))`,
    );
    await queryRunner.query(
      `CREATE TABLE "registeredSourceSystemEntityDataKey" ("sourceSystemId" varchar(255) NOT NULL, "entity" varchar(255) NOT NULL, "generatedDdhKey" varchar(255) NOT NULL, "sourceRecordChangeDateTime" datetime, "sourceRecordExistanceDateTime" datetime, "ddhKeyCreationDateTime" datetime2 NOT NULL CONSTRAINT "DF_e712230b251e62c8277fc7b4ab4" DEFAULT getdate(), "ddhKeyUpdateDateTime" datetime2 NOT NULL CONSTRAINT "DF_232d63075328ddf15b804cad54e" DEFAULT getdate(), "integrationId" varchar(255), "entityVersion" int, "valueHash" varchar(255), "deletedInSource" bit NOT NULL CONSTRAINT "DF_d5fcd778e93283320ec979e2d35" DEFAULT 0, "deletedInSourceDateTime" datetime, "ddhInitialPersistenceDateTime" datetime, "ddhUpdatePersistenceDateTime" datetime, "hashInitialDateTime" datetime, "hashCheckedDateTime" datetime, CONSTRAINT "PK_0c785215b644bfbc602661e3a9f" PRIMARY KEY ("sourceSystemId", "entity", "generatedDdhKey"))`,
    );
    await queryRunner.query(
      `CREATE TABLE "entityRelations" ("leftSourceSystemId" varchar(255) NOT NULL, "leftEntity" varchar(255) NOT NULL, "leftGeneratedKey" varchar(255) NOT NULL, "rightSourceSystemId" varchar(255) NOT NULL, "rightEntity" varchar(255) NOT NULL, "rightGeneratedKey" varchar(255) NOT NULL, "relationType" varchar(255) NOT NULL, "expandTypeName" varchar(255), "sourceRecordExistenceDateTime" datetime, "relationInitialPersistenceDateTime" datetime2 NOT NULL CONSTRAINT "DF_9db36e602d0806e3beecd8e518f" DEFAULT getdate(), "relationUpdatePersistenceDateTime" datetime2 NOT NULL CONSTRAINT "DF_b4f566bcee745470231e1fa1c0b" DEFAULT getdate(), "relationDeleted" bit NOT NULL CONSTRAINT "DF_7d0a603903db6a52925accc0275" DEFAULT 0, "relationDeletionDateTime" datetime, CONSTRAINT "PK_7115043658fe5fcb66b9de64520" PRIMARY KEY ("leftSourceSystemId", "leftEntity", "leftGeneratedKey", "rightSourceSystemId", "rightEntity", "rightGeneratedKey", "relationType"))`,
    );
    await queryRunner.query(
      `CREATE TABLE "leftRightEntityRelations" ("leftSourceSystemId" varchar(255) NOT NULL, "leftEntity" varchar(255) NOT NULL, "rightSourceSystemId" varchar(255) NOT NULL, "rightEntity" varchar(255) NOT NULL, "propagateDelete" varchar(255) CONSTRAINT CHK_7e8aa1a04a20828e1a9ea4b73e_ENUM CHECK(propagateDelete IN ('LeftToRight','RightToLeft')), "relationType" varchar(255) CONSTRAINT CHK_3bd1f41ab4702706dffd468646_ENUM CHECK(relationType IN ('ParentChild','Expand')) NOT NULL, "expandTypeName" varchar(255), CONSTRAINT "PK_89b17e2b3df64a4d42ed9ab2476" PRIMARY KEY ("leftSourceSystemId", "leftEntity", "rightSourceSystemId", "rightEntity", "relationType"))`,
    );
    await queryRunner.query(
      `CREATE TABLE "leftRightEntityRelationsMapping" ("leftSourceSystemId" varchar(255) NOT NULL, "leftEntity" varchar(255) NOT NULL, "rightSourceSystemId" varchar(255) NOT NULL, "rightEntity" varchar(255) NOT NULL, "leftAttribute" varchar(255) NOT NULL, "rightAttribute" varchar(255), CONSTRAINT "PK_d06747f8a65fd1b01d1840f0455" PRIMARY KEY ("leftSourceSystemId", "leftEntity", "rightSourceSystemId", "rightEntity", "leftAttribute"))`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE "leftRightEntityRelationsMapping"`);
    await queryRunner.query(`DROP TABLE "leftRightEntityRelations"`);
    await queryRunner.query(`DROP TABLE "entityRelations"`);
    await queryRunner.query(`DROP TABLE "registeredSourceSystemEntityDataKey"`);
    await queryRunner.query(`DROP TABLE "job"`);
    await queryRunner.query(`DROP TABLE "sourceSystemEntity"`);
    await queryRunner.query(`DROP TABLE "skill"`);
  }
}
