import {fastifyHelmet} from '@fastify/helmet';
import {fastifySwagger} from '@fastify/swagger';
import {fastifySwaggerUi} from '@fastify/swagger-ui';
import {jsonSchemaTransform, serializerCompiler, validatorCompiler} from 'fastify-type-provider-zod';
import {close_db_connection} from './config/typeorm-config';
import * as fastifyRatelimit from '@fastify/rate-limit';

import {server} from './config/fastify-config';
import {EntityService} from './services/entityService';
import {mssql_datasource} from './config/typeorm-config';
import {getConfig} from './config/config';

// * decorate the request so that performance is better and we pass the env variable everywhere
declare module 'fastify' {
  export interface FastifyInstance {
    entity_service: EntityService;
  }
}

getConfig();

mssql_datasource
  .initialize()
  .then(async () => {
    try {
      await server.register(import('./routes/api/v1/health-probes'));

      await server.register(fastifySwagger, {
        openapi: {
          info: {title: 'DATAHUB', version: '1.0.0'},
          components: {
            securitySchemes: {
              authorization_access_token: {
                type: 'http',
                scheme: 'bearer',
                bearerFormat: 'JWT',
              },
              authorization_refresh_token: {
                type: 'http',
                scheme: 'bearer',
                bearerFormat: 'JWT',
              },
            },
          },
        },
        transform: jsonSchemaTransform,
      });
      await server.register(fastifySwaggerUi, {
        routePrefix: '/api/docs',
        uiConfig: {layout: 'BaseLayout'},
      });
      // * Add schema validator and serializer
      server.setValidatorCompiler(validatorCompiler);
      server.setSerializerCompiler(serializerCompiler);

      // * Custom error handler
      server.setErrorHandler(async (error, request, reply) => {
        if (error.statusCode === 429) {
          return await reply.code(429).send({message: 'You hit the rate limit! Slow down please!'});
        }
        console.log('error request: ', request.body);
        const status_code = error.statusCode || 500;
        const message = error.message || 'Internal Server Error';
        return await reply.status(status_code).send({message: message});
      });

      server.decorate('entity_service', new EntityService());

      //* Helmet helps secure Express apps by setting HTTP response headers.
      await server.register(fastifyHelmet);

      //* Added rate limiting for API endpoints except for local development 😁
      server.register(fastifyRatelimit, {
        allowList: ['127.0.0.1'],
        max: 10000,
        timeWindow: '1 minute',
      });

      //* All routes foreseen on the fastify instance.
      await server.register(import('./routes/api/v1/entity'));

      server.addHook('onClose', async () => {
        await close_db_connection();
        console.log('Fastify & Postgress Pool closed');
      });

      await server.listen({port: 8080, host: '0.0.0.0'});
    } catch (err) {
      server.log.error(err);
      throw err;
    }
  })
  .catch(error => {
    console.log(error);
  });
