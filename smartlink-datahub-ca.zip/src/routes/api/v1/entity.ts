import {type FastifyInstance} from 'fastify';
import {type ZodTypeProvider} from 'fastify-type-provider-zod';
import {error_msg_scheme} from '../../../schemas/error_msg';
import {registerResponseSchema} from '../../../schemas/registerResponse';
import {z} from 'zod';

export default function (server: FastifyInstance, _options: unknown, done: () => void): void {
  server.withTypeProvider<ZodTypeProvider>().route({
    url: '/api/v1/entity/register',
    method: 'PUT',
    schema: {
      tags: ['Entity'],
      querystring: z.object({
        sourceSystem: z.string(),
        entityType: z.string(),
      }),
      body: z.any(),
      response: {
        200: registerResponseSchema,

        400: error_msg_scheme,
      },
    },
    handler: async (req, res) => {
      try {
        const result = await server.entity_service.register(req.query.sourceSystem, req.query.entityType, req.body);
        return await res.code(200).send(result);
      } catch (error) {
        if (error instanceof Error) {
          return await res.code(400).send({message: 'Something went wrong in registering the entity.'});
        }
        throw error;
      }
    },
  });

  server.withTypeProvider<ZodTypeProvider>().route({
    url: '/api/v1/entity/register/bulk',
    method: 'PUT',
    schema: {
      tags: ['Entity'],
      querystring: z.object({
        sourceSystem: z.string(),
        entityType: z.string(),
      }),
      body: z.any(),
      response: {
        200: registerResponseSchema,

        400: error_msg_scheme,
      },
    },
    handler: async (req, res) => {
      try {
        const result = await server.entity_service.registerBulk(req.query.sourceSystem, req.query.entityType, req.body);
        return await res.code(200).send(result);
      } catch (error) {
        if (error instanceof Error) {
          return await res.code(400).send({message: 'Something went wrong in registering the entity.'});
        }
        throw error;
      }
    },
  });

  server.withTypeProvider<ZodTypeProvider>().route({
    url: '/api/v1/entity/deleteById',
    method: 'DELETE',
    schema: {
      tags: ['Entity'],
      querystring: z.object({
        sourceSystem: z.string(),
        entityType: z.string(),
        id: z.coerce.number(),
      }),
      response: {
        200: z.object({message: z.string()}),

        400: error_msg_scheme,
      },
    },
    handler: async (req, res) => {
      try {
        await server.entity_service.deleteById(req.query.sourceSystem, req.query.entityType, req.query.id);
        return await res.code(200).send({message: 'Success'});
      } catch (error) {
        if (error instanceof Error) {
          return await res.code(400).send({message: 'Something went wrong deleting the entity.'});
        }
        throw error;
      }
    },
  });

  server.withTypeProvider<ZodTypeProvider>().route({
    url: '/api/v1/entity/deleteByExistance',
    method: 'DELETE',
    schema: {
      tags: ['Entity'],
      querystring: z.object({
        sourceSystem: z.string(),
        entityType: z.string(),
      }),
      body: z.any(),
      response: {
        200: z.object({message: z.string()}),

        400: error_msg_scheme,
      },
    },
    handler: async (req, res) => {
      try {
        await server.entity_service.deleteByExistance(req.query.sourceSystem, req.query.entityType, req.body);
        return await res.code(200).send({message: 'Success'});
      } catch (error) {
        if (error instanceof Error) {
          return await res.code(400).send({message: 'Something went wrong deleting the entity.'});
        }
        throw error;
      }
    },
  });

  server.withTypeProvider<ZodTypeProvider>().route({
    url: '/api/v1/entity/deleteAfterFullLoadWithCutOff',
    method: 'DELETE',
    schema: {
      tags: ['Entity'],
      querystring: z.object({
        sourceSystem: z.string(),
        entityType: z.string(),
      }),
      body: z.any(),
      response: {
        200: z.object({message: z.string()}),

        400: error_msg_scheme,
      },
    },
    handler: async (req, res) => {
      try {
        await server.entity_service.deleteAfterFullLoadWithCutOff(req.query.sourceSystem, req.query.entityType, req.body);
        return await res.code(200).send({message: 'Success'});
      } catch (error) {
        if (error instanceof Error) {
          return await res.code(400).send({message: 'Something went wrong deleting the entity.'});
        }
        throw error;
      }
    },
  });

  done();
}
