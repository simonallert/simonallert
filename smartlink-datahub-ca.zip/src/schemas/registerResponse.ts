import {z} from 'zod';

export const registerResponseSchema = z.object({
  success: z.array(z.string()),
  failed: z.array(
    z.object({
      reference: z.string(),
      message: z.string(),
    }),
  ),
});

export type registerResponse = z.infer<typeof registerResponseSchema>;

export function newRegisterBulkResponse(): registerResponse {
  return {
    success: [],
    failed: [],
  };
}
