import {IsNull, LessThan, MoreThan, Or} from 'typeorm';
import {mssql_datasource} from '../config/typeorm-config';
import {error} from 'console';
import {RegisteredSourceSystemEntityDataKey} from '../db/datahub/registeredSourceSystemEntityDataKey';
import {EntityRelations} from '../db/datahub/entityRelations';
import {newRegisterBulkResponse, registerResponse} from '../schemas/registerResponse';
import {SourceSystemEntity} from '../db/datahub/sourceSystemEntity';

export class EntityService {
  async register(sourceSystem: string, entityType: string, entity: any): Promise<registerResponse> {
    const entityConfig = await this.getEntityConfig(sourceSystem, entityType);

    const result = newRegisterBulkResponse();
    try {
      const ddhKey = await this.upsertEntity(entityConfig, entity);

      result.success.push(ddhKey.generatedDdhKey);
    } catch (error) {
      if (error instanceof Error) {
        console.error('Error registering entity:', error);
        result.failed.push({
          reference: `${sourceSystem}, ${entityType}, ${entity.id}`,
          message: error.message,
        });
      }
    }
    return result;
  }

  private async getEntityConfig(sourceSystem: string, entityType: string): Promise<SourceSystemEntity> {
    const entityConfig = await mssql_datasource.manager.findOne(SourceSystemEntity, {where: {sourceSystemId: sourceSystem, entity: entityType}});
    if (!entityConfig) {
      console.error('Source system entity config not found:', error);
      throw new Error('Could not find source system entity config');
    }
    return entityConfig;
  }

  private async upsertEntity(entityConfig: SourceSystemEntity, entity: any): Promise<RegisteredSourceSystemEntityDataKey> {
    const ddhKey = new RegisteredSourceSystemEntityDataKey(entityConfig, entity);
    entity.generatedDdhKey = ddhKey.generatedDdhKey;

    const foundKey = await mssql_datasource.manager.findOne(RegisteredSourceSystemEntityDataKey, {where: {generatedDdhKey: ddhKey.generatedDdhKey}});
    if (foundKey) {
      if (ddhKey.valueHash != foundKey.valueHash || !entityConfig.dataValueHashing || entityConfig.updateSourceTableContentOnEqualHash) {
        ddhKey.ddhUpdatePersistenceDateTime = new Date();
        ddhKey.hashCheckedDateTime = new Date();
        await mssql_datasource.manager.transaction(async transactionalEntityManager => {
          await transactionalEntityManager.save(ddhKey);
          await transactionalEntityManager.getRepository(entityConfig.entity).save(entity);
        });
      } else {
        // could cause performance issues?
        foundKey.hashCheckedDateTime = new Date();
        await mssql_datasource.manager.save(foundKey);
      }
    } else {
      ddhKey.ddhInitialPersistenceDateTime = new Date();
      ddhKey.ddhUpdatePersistenceDateTime = new Date();
      await mssql_datasource.manager.transaction(async transactionalEntityManager => {
        await transactionalEntityManager.save(ddhKey);
        await transactionalEntityManager.getRepository(entityConfig.entity).save(entity);
      });
    }
    return ddhKey;
  }

  async registerBulk(sourceSystem: string, entityType: string, jsonData: any): Promise<registerResponse> {
    const entityConfig = await this.getEntityConfig(sourceSystem, entityType);

    const result = newRegisterBulkResponse();
    for (const entity of jsonData.results) {
      try {
        const ddhKey = await this.upsertEntity(entityConfig, entity);

        result.success.push(ddhKey.generatedDdhKey);
      } catch (error) {
        if (error instanceof Error) {
          console.error('Error registering entity:', error);
          result.failed.push({
            reference: `${sourceSystem}, ${entityType}, ${jsonData.id}`,
            message: error.message,
          });
        }
      }
    }

    return result;
  }

  async deleteByExistance(sourceSystem: string, entityType: string, jsonData: any): Promise<void> {
    try {
      await this.deleteAfterFullLoad(sourceSystem, entityType, jsonData);
    } catch (error) {
      console.error('Error deleting entities:', error);
      throw new Error('Could not delete entity');
    }
  }

  async deleteAfterFullLoadWithCutOff(sourceSystem: string, entityType: string, jsonData: any): Promise<void> {
    try {
      await this.deleteAfterFullLoad(sourceSystem, entityType, jsonData, true);
    } catch (error) {
      console.error('Error deleting entities:', error);
      throw new Error('Could not delete entity');
    }
  }

  async deleteById(sourceSystem: string, entityType: string, id: number): Promise<void> {
    try {
      const entityConfig = await this.getEntityConfig(sourceSystem, entityType);

      const key = RegisteredSourceSystemEntityDataKey.generateDdhKeyWithId(entityConfig, id);

      await this.softDeleteKeyAndEntity(key);

      const expandRelations = await mssql_datasource.manager.find(EntityRelations, {where: {leftGeneratedKey: key}});
      for (const relation of expandRelations) {
        await this.softDeleteKeyAndEntity(relation.rightGeneratedKey);
      }
    } catch (error) {
      console.error('Error deleting entity:', error);
      throw new Error('Could not delete entity');
    }
  }

  private async softDeleteKeyAndEntity(key: string): Promise<void> {
    const ddhKey = await mssql_datasource.manager.findOne(RegisteredSourceSystemEntityDataKey, {where: {generatedDdhKey: key}});
    if (ddhKey) {
      ddhKey.deletedInSource = true;
      ddhKey.deletedInSourceDateTime = new Date();
    } else {
      throw new Error('Could not find entity key');
    }

    const repo = mssql_datasource.getRepository(ddhKey.entity);
    const entity = await repo.findOne({where: {generatedDdhKey: key}});
    if (entity) {
      entity.deletionFlag = true;
    } else {
      throw new Error('Could not find entity');
    }

    await mssql_datasource.manager.transaction(async transactionalEntityManager => {
      await transactionalEntityManager.save(ddhKey);
      if (entity) {
        await repo.save(entity);
      }
    });
  }

  async deleteAfterFullLoad(sourceSystem: string, entityType: string, jsonData: any, withCutOff?: boolean): Promise<void> {
    const entityConfig = await this.getEntityConfig(sourceSystem, entityType);

    if (!entityConfig.deletionDetectionActive) {
      return;
    }

    //performance?
    const ExistanceCheckDate = new Date();
    for (const entity of jsonData.results) {
      const key = RegisteredSourceSystemEntityDataKey.generateDdhKeyForEntity(entityConfig, entity);

      let where;
      if (withCutOff && entityConfig.cutOffDateTimeAttribute) {
        where = {generatedDdhKey: key, ddhUpdatePersistenceDateTime: MoreThan(entityConfig.cutOffDateTimeAttribute)};
      } else {
        where = {generatedDdhKey: key};
      }

      const foundKey = await mssql_datasource.manager.findOne(RegisteredSourceSystemEntityDataKey, {where: where});
      if (foundKey) {
        foundKey.sourceRecordExistanceDateTime = ExistanceCheckDate;
        await mssql_datasource.manager.save(foundKey);
      }
    }

    const entitiesNotPresent = await mssql_datasource.manager.findBy(RegisteredSourceSystemEntityDataKey, {sourceRecordExistanceDateTime: Or(LessThan(ExistanceCheckDate), IsNull())});

    for (const entityNotPresent of entitiesNotPresent) {
      if (!(withCutOff && (entityConfig.cutOffDateTimeAttribute > entityNotPresent.ddhUpdatePersistenceDateTime))) {
        await this.softDeleteKeyAndEntity(entityNotPresent.generatedDdhKey);
      }
    }
  }
}

export default EntityService;
