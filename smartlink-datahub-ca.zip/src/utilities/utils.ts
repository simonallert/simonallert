export const average: (array: number[]) => number = (array: number[]) => array.reduce((acc, val) => acc + val, 0) / array.length;

export function utility_example(testparameter: string): string {
  return testparameter;
}
